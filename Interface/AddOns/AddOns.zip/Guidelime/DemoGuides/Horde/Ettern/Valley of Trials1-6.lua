Guidelime.registerGuide([[
[DL1-42 https://www.curseforge.com/wow/addons/guidelime_ettern Guidelime_Ettern]
[N1-6 Valley of Trials]
[GA Orc,Troll]
[D A guide created by |cFF69CCF0Ettern|r\\www.dreamstate.gg]
[G43.3,68.5 Durotar]Accept [QA4641 Your Place In The World].
[G42.6,69]Accept [QA1485 Vile Familiars][A Warlock].
[G42.1,68.3]Turn in [QT4641 Your Place In The World]. \\Accept [QA788 Cutting Teeth].
Unequip leggings, boots and weapon then sell it together with Tough Jerky to [V]vendor[G40.6,67.8] so you have atleast 10 copper.[A Warlock]
[G40.65,68.51][T]|cFF9482C9 Learn new skills:\\- Immolate (Rank 1)|r[A Warlock]. 
[G40.6,62.6]Pickup [QA790 Sarkoth]. \\Kill Mottled Boars along your way for [QC788 Cutting Teeth][O]
Kill Sarkoth[G40.5,67.3] for [QC790 Sarkoth] and loot him.
[G40.6,62.6]Turn in [QT790 Sarkoth]. \\Accept [QA804 Sarkoth].
Kill Mottled Boars and finish [QC788 Cutting Teeth].
[G44.7,57]Do [QC1485 Vile Familiars][A Warlock].
Grind mobs until you're [XP4-600 600 XP from level 4][A Warlock].
Grind mobs until you're [XP3-250 250 XP from level 3][A Mage,Warrior,Hunter,Rogue,Shaman,Priest].
[G42.6,69]Turn in [QT1485 Vile Familiars]. Accept [QA1499 Vile Familiars][A Warlock]
[G42.8,69.1]Next to you, turn in [QT1499 Vile Familiars]. Accept [QA794 Burning Blade Medallion].[A Warlock]
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA3086 Glyphic Tablet][A Troll, Mage].
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA3065 Simple Tablet][A Troll, Warrior].
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA3082 Etched Tablet][A Troll, Hunter].
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA3083 Encrypted Tablet][A Troll, Rogue].
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA3084 Rune-Inscribed Tablet][A Troll, Shaman].
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA3085 Hallowed Tablet][A Priest].
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA3088 Encrypted Parchment][A Orc, Rogue].
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA3087 Etched Parchment][A Orc, Hunter].
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA3089 Rune-Inscribed Parchment][A Orc, Shaman].
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA2383 Simple Parchment][A Orc, Warrior].
[G42.1,68.3]Turn in [QT788 Cutting Teeth] and [QT804 Sarkoth].\\Accept [QA789 Sting of the Scorpid] and [QA3090 Tainted Parchment][A Warlock].
[G41.3,68]Go into the cave and turn in [QT3083 Encrypted Tablet][A Troll, Rogue].
[G41.3,68]Go into the cave and turn in [QT3088 Encrypted Parchment][A Orc, Rogue].
Go further into the cave and [V]sell items here[G40.6,67.8][A Warlock].
[G40.65,68.51]Next to you, turn in [QT3090 Tainted Parchment][A Warlock]. \\|cFF9482C9[T]Learn new skills:\\ - Corruption (Rank 1)|r
[G42.7,67.3]Accept [QA4402 Galgar's Cactus Apple Surprise].\\[V]Sell items here.
[G42.5,69]Turn in [QT3086 Glyphic Tablet]. \\|cFF69CCF0[T]Learn new skills:\\ - Arcane Intellect (Rank 1)|r[A Mage]
[G42.4,68.8]Turn in [QT3085 Hallowed Tablet]. \\|cFFFFFFFF[T]Learn new skills: \\ - Power Word:Fortitude (Rank 1)|r[A Priest]
[G42.4,69]Turn in [QT3084 Rune-Inscribed Tablet]. \\|cFF0070DE[T]Learn new skills: \\ - Rockbiter Weapon (Rank 1)|r[A Troll, Shaman]
[G42.4,69]Turn in [QT3089 Rune-Inscribed Parchment]. \\|cFF0070DE[T]Learn new skills: \\ - Rockbiter Weapon (Rank 1)|r[A Orc, Shaman]
[G42.8,69.1]Accept [QA792 Vile Familiars] next to the wagon.[A Mage,Warrior,Hunter,Rogue,Shaman,Priest]
[G42.9,69.4]Turn in [QT2383 Simple Parchment]. \\|cFFC79C6E[T]Learn new skills: \\ - Battle Shout (Rank 1)|r[A Orc, Warrior]
[G42.9,69.4]Turn in [QT3065 Simple Tablet]. \\|cFFC79C6E[T]Learn new skills: \\ - Battle Shout (Rank 1)|r[A Troll, Warrior]
[G44.63,68.67]Accept [QA5441 Lazy Peons].
Focus on doing [G46.29,60.62Durotar][QC5441 Lazy Peons](See icon[L 41.2,72.7][L 42.3,73.2][L 44.7,72.8][L 47.6,69.4][L 45.6,65.7][L 47.2,65.5][L 46.8,60.8][L 47.1,57.9][L 43.8,57.8][L 42.7,57.4][L 41.3,58.8][L 40.9,60.4][L 38.8,61.9] on map for locations) together with the following quests: \\[G46.29,60.62Durotar][QC4402 Galgar's Cactus Apple Surprise][O] - Pick up cactus apples from plants\\[G46.29,60.62Durotar][QC789 Sting of the Scorpid][O] - Kill Scorpids. \\Head back to town once Lazy Peons is done. You dont need to finish the other quests now.[A Warlock]
[G44.63,68.67]Turn in [QT5441 Lazy Peons]. \\Accept [QA6394 Thazz'ril's Pick].[A Warlock]
Do [QC4402 Galgar's Cactus Apple Surprise] and [QC789 Sting of the Scorpid] while heading to the cave up north[G44.7,57].[A Warlock]
Enter the cave and pick up Thazz'ril's Pick[G43.7,53.8] for [QC6394 Thazz'ril's Pick].[A Warlock]
Go further into the cave and kill Yarrog Baneshadow[G42.7,53] for [QC794 Burning Blade Medallion].[A Warlock]
Use Hearthstone to [H Valley of Trials][O][A Warlock]
From now on do the following quests:\\[QC5441 Lazy Peons] (See icon[L 41.2,72.7][L 42.3,73.2][L 44.7,72.8][L 47.6,69.4][L 45.6,65.7][L 47.2,65.5][L 46.8,60.8][L 47.1,57.9][L 43.8,57.8][L 42.7,57.4][L 41.3,58.8][L 40.9,60.4][L 38.8,61.9] on map for locations) together with:\\[G46.29,60.62Durotar][QC4402 Galgar's Cactus Apple Surprise]\\[G46.29,60.62Durotar][QC789 Sting of the Scorpid][A Mage,Warrior,Hunter,Rogue,Shaman,Priest]
[G45.3,57.2]Kill Vile Familiars for [QC792 Vile Familiars][A Mage,Warrior,Hunter,Rogue,Shaman,Priest]
Grind mobs until you're [XP4-1000 1000 XP from level 4][A Mage,Warrior,Hunter,Rogue,Shaman,Priest].
Use Hearthstone to [H Valley of Trials][O][O][A Mage,Warrior,Hunter,Rogue,Shaman,Priest]
[G44.63,68.67]Turn in [QT5441 Lazy Peons].\\Accept [QA6394 Thazz'ril's Pick].[A Mage,Warrior,Hunter,Rogue,Shaman,Priest]
[G42.7,67.3]Turn in [QT4402 Galgar's Cactus Apple Surprise].\\[V]Sell items here.
[G42.1,68.3]Turn in [QT789 Sting of the Scorpid].
[G42.4,69]|cFF0070DE[T]Learn new skills: \\ - Earth Shock (Rank 1)|r[A Shaman]
[G42.4,68.8]|cFFFFFFFF[T]Learn new skills: \\ - Shadow Word:Pain (Rank 1) \\ - Lesser Heal (Rank 2)|r[A Priest]
[G42.5,69]|cFF69CCF0[T]Learn new skills:\\ - Conjure Water (Rank 1)\\- Frostbolt(Rank 1)|r[A Mage]
Next to you, accept [QA1516 Call of Earth (part 1)][G42.4,69.2][A Shaman].
[G42.8,69.1]Turn in [QT792 Vile Familiars]. \\Accept [QA794 Burning Blade Medallion].[A Mage,Warrior,Hunter,Rogue,Shaman,Priest]
[G42.8,69.3]|cFFABD473[T]Learn new skills:\\ - Serpent Sting (Rank 1)|r[A Hunter]
[G42.9,69.4]|cFFC79C6E[T]Learn new skills: \\ - Charge (Rank 1)|r[A Warrior]
Enter the cave up north and pick up Thazz'ril's Pick[G43.7,53.8] for [QC6394 Thazz'ril's Pick].[A Mage,Warrior,Hunter,Rogue,Shaman,Priest]
Go further into the cave and kill Yarrog Baneshadow[G42.7,53] for [QC794 Burning Blade Medallion]. \\He is located at the end of the cave.[A Mage,Warrior,Hunter,Rogue,Shaman,Priest]
Kill felstalkers inside the cave for [QC1516 Call of Earth (part 1)][A Shaman].
Use [H unstuck] feature on the platform where Yarrog is located[A Mage,Warrior,Hunter,Rogue,Shaman,Priest]
[G42.8,69.1]Turn in [QT794 Burning Blade Medallion]. \\Accept [QA805 Report to Sen'jin Village]
[G42.4,68.8]Accept [QA5649 In Favor of Spirituality][A Priest]
[G42.4,69.2]Turn in [QT1516 Call of Earth (part 1)]. \\Accept [QA1517 Call of Earth (part 2)][A Shaman]
[G42.7,67.3][V]Sell items here.
[G44.63,68.67]Turn in [QT6394 Thazz'ril's Pick]
Go to [G 41.7,73.2], then go up the hill to[G 40.7,74.2]. Turn left and continue to follow the path up [G 42.1,74.8] until you see a big stone[G 44,76.2].[A Shaman]
Open your inventory and use the provided item, Earth Sapta. \\Turn in [QT1517 Call of Earth (part 2)]. \\Accept [QA1518 Call of Earth (part 3)][A Shaman]
Run back/unstuck - so you end up in starting-town.[OC][A Shaman]
[G42.4,69.2]Turn in [QT1518 Call of Earth (part 3)][A Shaman]
Leave starting zone and pick up [QA2161 A Peon's Burden][G52.1,68.3].
[G52.23,71.88]Grind mobs around Sen'jin Village until level [XP6][A Mage]
[NX 6-12 Durotar]

]],"Ettern")
