Guidelime.registerGuide([[
[DL1-60 https://www.curseforge.com/wow/addons/guidelime_markymark Guidelime_MarkyMark]
[D*MarkyMark*'s 1-60 guide\\https://www.twitch.tv/darealmarkymark\\(best suited for a group of at least 2, if not 3+)]
[GA Dwarf,Gnome]
[N1-5 Dun Morogh]
[NX5-12 Dun Morogh/Loch Modan]
Accept [QA179 Dwarven Outfitters]
Do [QC179 Dwarven Outfitters]
Turn in [QT179 Dwarven Outfitters]
Accept [QA233 Coldridge Valley Mail Delivery]
Accept Class Quest
Accept [QA170 A New Threat]
Do [QC170 A New Threat] while running west to the boar quest
Turn in [QT233 Coldridge Valley Mail Delivery]
Accept [QA183 The Boar Hunter]
Accept [QA234 Coldridge Valley Mail Delivery Part 2]
Do [QC183 The Boar Hunter]
Turn in [QT183 The Boar Hunter]
Turn in [QT234 Coldridge Valley Mail Delivery]
Accept [QA182 The Troll Cave]
Do [QC182 The Troll Cave]
Turn in [QT182 The Troll Cave], accept [QA218 The Stolen Journal]
Accept [QA3364 Scalding Mornbrew Delivery]
Turn in [QT3364 Scalding Mornbrew Delivery]
Accept [QA3365 Bring Back The Mug]
Turn in Class Quest
[T Train] new abilities
Turn in [QT3365 Bring Back The Mug]
Do [QC218 The Stolen Journal]
Turn in [QT218 The Stolen Journal]
Accept [QA282 Senir's Observations]
Turn in [QT282 Senir's Observations]
Accept [QA420 Senir's Observations Part 2]
Accept [QA2160 Supplies to Tannok]
Grind through the cave to Dun Morogh

]],"MarkyMark")
