Guidelime.registerGuide([[
[DL20-60 https://www.curseforge.com/wow/addons/guidelime_shiku Guidelime_Shiku]
[N 20-20 Undead Warlock Class Quest]
[GA Warlock]
[D Level 20 Class Quest for Horde Horde Warlocks]
[G83,27Undercity]Head to Undercity and Accept[QA1472][A Horde]
[G85,14.8]Enter the temple and turn in[QT1472][A Horde]
Accept[QA1476][A Horde]
Fly to Silverpine Forest[A Horde]
[G46,83.6Silverpine Forest]Find Dalin in Southern Silverpine and kill him for [QC1476,1][A Horde]
[G60.2,18.6Hillsbrad Foothills]Grab the flight path in Hillsbrad Foothills[A Horde]
[G73,32.6Arathi Highlands]Stick to the road and grab the flightpath in Arathi Highlands[A Horde]
[G50,12.8Wetlands]Run South into The Wetlands, look for Comar Villard and kill him for [QC1476][A Horde]
[G83,27Undercity]Return to Undercity and turn in[QT1476][A Horde]
Accept[QA1474][A Horde]
Use the same summoning circle from the Voidwalker quest to summon the succubus and kill her, then turn in[QT1474][A Horde]

]],"Class Quests- by Shikushiku")
