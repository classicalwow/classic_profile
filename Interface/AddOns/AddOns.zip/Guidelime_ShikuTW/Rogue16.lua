Guidelime.registerGuide(
[[
[N 16-16 Rogue Lockpicking Quest]
[GA Alliance,Rogue]
[D Rogue Level 16 Class Quest]
You must be level 16 to complete this quest! 
Fly/Run to Stormwind[OC]
[G75.8,60Stormwind City]Accept[QA2281]
[G66.2,62.4]Grab the flight path if you don't have it, then fly to Lakeshire in Redridge Mountains if you have it, otherwise we have to run.[OC]
[G30.6,59.2Redridge Mountains]Grab the flightpath if you need it.
[G28,52.2]Turn in[QT2281]
Accept[QA2282]
[G52,45]Practice your lockpicking on the 5 lockboxes here. You can get up to skill 100 here, but once you're 75 you can open Lucius' Lockbox for the quest. [QC2282]
[G28,52.2]Turn in[QT2282]
]],"Class Quests- by Shikushiku")