Guidelime.registerGuide(
[[
[N 20-20 Rogue Thistle Tea + Poisons]
[GA Alliance,Rogue]
[D Rogue Thistle Tea/Poisons Quest]
You must have 75 lockpicking to complete this quest chain!
Fly/Run to Stormwind[OC]
[G75.8,59.8Stormwind City]Accept[QA2360]
If you have the flightpath in Westfall, fly to Sentinel Hill[OC]
[G68.4,70.2Westfall]Turn in[QT2360]
Accept[QA2359]
Around the tower, there should be a mob named Malformed Defias Drone - Pickpocket him for his key.
Once you have the key, stealth your way up the tower and use Sap on Klaven Mortwake. Lockpick the Duskwood chest and loot the journal[QC2359]
[G56.4,52.6Westfall]Fly back to Stormwind
[G75.8,59.8Stormwind City]Turn in[QT2359]
If you have a druid friend you can skip the next quest and have him cure your poison.
Accept[QA2607]
[G78,59.2]Go to the basement and talk to the doctor, MAKE SURE HE IS TARGETED and /lay while he examines you, then tell you what items he needs to cure you.
[G55.4,7.8][V]Buy a Bronze Tube
[G40,46]Loot the silk from the ground here
[G64.2,61][V]Buy Simple Wildflowers
[G76.8,59.8][V]Buy Leaded Vial
[G78,59.2]Turn in[QT2607]
]],"Class Quests- by Shikushiku")