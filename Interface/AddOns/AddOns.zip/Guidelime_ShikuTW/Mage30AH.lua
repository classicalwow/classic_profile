Guidelime.registerGuide(
[[
[N 30-30 Mage Class Quest]
[GA Mage]
[D Wand Class Quest for Mages Allaince AND Horde]
YOU MUST BE LEVEL 30 TO START THIS QUEST, BUT IT IS DIFFICULT - MAY NEED HELP OR MORE LEVELS!
[G38.8,85.4Orgrimmar]Accept[QA1947] from one of the mage trainers[A Horde]
Fly to Dustwallow Marsh if you have the flightpath[A Horde]
Fly to The Crossroads, run South, and then east into Dustwallow Marsh if you did not have the flightpath[A Horde]
[G35.6,31.8Dustwallow Marsh]Grab the flightpath if you didn't have it[A Horde]
[G38.6,79.4Stormwind City]Accept[QA1947]From the mage trainers.[A Alliance]
Fly to Menethil Harbor[A Alliance]
Take the boat to Theramore Isle from the northern dock.[A Alliance]
[G67.4,51.2Dustwallow Marsh]Grab the flightpath if you need it[A Alliance]
[G46,57Dustwallow Marsh]Turn in[QT1947]
Accept[QA1049]
Head to the Shimmering flats in Thousand Needles, if you have the Gadgetzan flight path, fly to Gadgetzan and then run north.[OC]
[G29.7,48.5]If you don't have the Gadgetzan Flightpath, run this direction and then West into The Barrens[OC]
[G45.2,84.7The Barrens]Run South in the Barrens towards the Great Lift, alliance players be careful the guards will aggro you, take the elevator down into Thousand Needles[OC]
[G78.2,75.8]Turn in[QT1949]
Accept[QA1950]
[G79.6,75.6Thousand Needles]Go to the Chicken and target him, then type /beckon, talk to him in his human form.
[G78.2,75.8]Turn in[QT1950]
Accept[QA1951]
If you didn't have the Gadgetzan Flightpath, now is a great time to run south to Gadgetzan and pick it up!
You have to do the Library wing of the scarlet monestary dungeon now. This guide won't cover the dungeon, complete the dungeon. \\ It is a large book jutting out the wall to the left once you walk into the Athenaeum inside the dungeon.
After you have the book, make your way back to Dustwallow Marsh.
[G46,57Dustwallow Marsh]Turn in[QT1951]
[QA1948]
You'll have to head to Arathi Highlands now. On your way, check your nearest Auction house for a Jade[OC]
[G45.8,46.2Arathi Highlands]If you didn't have the flight path, grab it![A Alliance]
[G73,32.6Arathi Highlands]If you didn't have the flight path, grab it![A Horde]
[G65,63Arathi Highlands]Gather 10 Witherbark Totem Sticks[OC]
[G52,50]Go to the Circle of Outer Binding and kill Elementals until the center is clear, then use your sticks to charge them into a bramble. Right click it on the center of the stone.[QC1948]
Once complete, fly to Menethil Harbor, then take the boat to Theramore[A Alliance]
Once complete, fly to Undercity, take the Zeppelin to Org, and Fly to Dustwallow Marsh[A Horde]
[G46,57Dustwallow Marsh]Turn in[QT1951]
Accept[QA1952]
After the ritual, speak to Tabatha to select your wand!
]],"Class Quests- by Shikushiku")