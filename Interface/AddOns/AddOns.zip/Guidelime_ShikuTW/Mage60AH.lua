Guidelime.registerGuide(
[[
[N 60-60 Mage Class Quest]
[GA Mage]
[D Polymorph Pig Class Quest]
YOU MUST BE LEVEL 60 TO START THIS QUEST!
Make your way to Azshara!
[G28,50Azshara]Speak to Sanath Lim-yo to be teleported.
Accept[QA9362]from the archmage at the top of the tower[OC]
Teleport back down
[G39,53]Head to the temple entrance and kill Warlord Krellian for the shell.[QC9362]
[G28,50]Teleport back up.
Turn in[QT9362] at the top of the tower.
Accept[QA9364]
Teleport back down
[G39,53]Head back to the temple. You have to polymorph the Spitelash mobs, wait for them to turn into weak clones, then you should be able to 1 shot them. \\ Repeat 50 times until complete! [QC9364]
[G28,50Azshara]Once more, teleport up, and run to the top of the tower.
Turn in[QT9364]
Congrats you can turn people into pigs!
]],"Class Quests- by Shikushiku")