Guidelime.registerGuide(
[[
[N 56-57 Burning Steppes]
[GA Alliance]
[D Made from Hakurai's Video Guide\\ https://twitch.tv/hakurai \\ Our guild is recruiting! \\ https://www.guilded.gg/KOABD]
Start killing mobs in excess and as you travel, without Silithus in the game at launch, you will have to make up the xp some how!
Start looking for a group for Dragonkin Menace for the rest of the guide, it's the first step in the Onyxia Attunement quest and it's elite.[OC]
Follow the road north east out of Redridge to get to the Burning Steppes[OC]
[G84.4,68.2Burning Steppes]Grab the flightpath
Accept[QA3823] from the dwarf next to him
Accept[QA4283]
From the Nelf to the east, accept[QA4182]
[G65.2,23.6]Up the ramp and across the bridge, Accept[QA4726]
[G65.2,23.6]Accept[QA4296]
ANYTIME YOU GET A GROUP, go do Dragonkin Menace[OC]
[G94,31]Accept his quest to show him your molt and then turn it in. Then accept the BRD quest from him, [QA4024]
[G90,43]Use the machine on the whelps, then kill them to loot the essence.[QC4726]
[G82,38]Kill Ogres in the area for [QC3823]
[G84.6,68.6]Turn in[QT3823]
Accept[QA3824]
IF you completed Dragonkin Menace, turn it in and accept[QA4183][OC]
[G40,55]On the way, grind blackrock mobs for the quest FIFTY![OC]
[G40,55]Kill Gortesh and kill him for [QC3824]
Finish killing mobs in the area for [QC4283]
[G54,40]Click on the statue to complete[QC4296]
Run around the ruins in the area looting relics to complete [QC3701]
[G65.2,23.6]Turn in[QT4296]
Turn in[QT4726]
Accept[QA4808]
[G84.6,68.6]Turn in[QT3824]
Turn in[QT4283]
Accept[QA3825]
[G75,37]Go up the path and cross the rope bridge. Kill the ogres, right click on the dirt by the cave for [QC3825]
[G84.6,68.6]Turn in[QT3825]
IF YOU COMPLETED DRAGONKIN MENACE AND TOOK THE FOLLOW UP -- Fly to Lakeshire -- Everyone else skip this section and Hearth to Menethil Harbor
LAKESHIRE - [G30,44Redridge Mountains]Turn in[QT4183]
LAKESHIRE - Accept [QA4184]
LAKESHIRE - Hearth to Menethil Harbor
REJOIN THE GUIDE NOW
If you did Sunken Temple - Fly to The Hinterlands [G33,75The Hinterlands] to turn in Jammal'an The Prophet[QT1446] -- Then follow the north path to Western Plague Lands to get to Chillwind Point
[G43,85.2Western Plaguelands]Chillwind Point
IF YOU DID NOT DO SUNKEN TEMPLE - Fly to Chillwind Point, or run there from Southshore/Aerie Peak.
[G43,85.2]Chillwind Point
[G42.8,84]Turn in[QT5091]
Accept[QA5092]
Turn in[QT6028]
Talk to the Argent Officer in front of the tent to get the Argent Dawn Commision. Equip it whenever you're killing undead into a trinket slot. They drop quest items for a rep turn in.
[G51,77]Kill Undead for [QC5092]
[G42.8,84]Turn in[QT5092]
Accept[QA5097]
Accept[QA5215]
[G42.8,84.2]Turn in[QT5215]
Accept[QA5216]
[V]Sell trash
Ride back through sorrow hill, then head north to head into Ruins of Andorhall[OC]
[G47,71]Place the torch next to the entrance of the tower, you don't need to go inside or aggro the elite inside, just use it from OUTSIDE the front door.[QC5097,4]
[G40,71]Place the torch[QC5097,1]
[G44,63]Place the torch[QC5097,3]
[G42,66]Place the torch[QC5097,2]
[G39,54]Second floor of the house, accept[QA5021]
[G36,57]Go to the Cauldron, try to clear around it before you get close to it. Once you get close the lord will spawn, kill him for [QC5216]
Turn in[QT5216]
Accept from the cauldron[QA5217]
[G38,55]Little crate inside the barn, loot it for [QT5021]
Accept by looting it again[QA5022]
[G42.8,84.]Turn in[QT5097]
Accept[QA5533]
Turn in nearby[QT5533]
Accept[QA5537]
Turn in[QT5217]
Accept[QA5219]
[V]Sell trash
You want to loot skeletal fragments from the skeletal type mobs in Andorhall between steps for your quest[OC]
[G46,52]Head to the Cauldron and clear around it, then kill the lord for [QC5219]
Turn in[QT5219]
Accept from the cauldron [QA5220]
[G47,50]Inside the barn, interact with the book to accept[QA5058]
Around the houses, look for a named skeleton called Wandering Skeelton, he drops an outhouse key.[OC]
Behind the houses is the outhouse, make sure you're full HP because you get attacked when you turn in [QT5058] at the outhouse.
On the 2nd floor of the farm house, turn in[QT5060] by right clicking the Cabinet
[G52,28]Accept[QA6004]
[G50,40]Kill Mages and Knights for [QC6004,3][QC6004,4]
[G41,50]Kill Medics and Hunters for[QC6004,1][QC6004,2]
[G51,28]Turn in[QT6004]
Accept[QA6023]
[G57,38]Kill Radley for [QC6023,1]If you get into melee range she wont use her bow.
[G55,23]Kill Durgen for[QC6023,2]
[G51,28]Turn in[QT6023]
Accept[QA6025]
The tower you're going to is filled with elites, you'll probably die.[OC]
[G45,18]Go to the tower by following the road to the east, ride inside, try to CC the mobs if you can, and run to the top of the tower[QC6025]
Try to run out but you'll probably die.[OC]
[G51,28]Turn in[QT6025]
[G42.8,84.2]Turn in[QT5220]
Accept[QA5222]
[G53,66]Head to the Cauldron and kill the lord for[QC5222]
Turn in[QT5222]
Accept[QA5223]
On the floor of the house, accept[QA5223]
Head north and kill wolves. They share spawn points with the spiders, so you may have to clear some of them[QC5223]
Head back to the Tauren and turn in[QT4984]
Accept[QA4985]
[G53,48]Kill Bears in the area for[QC4985]
Run back to the Tauren and turn in[QT4985]
Accept[QA4986]
Make sure you finished in Andorhall[QC5537]
[G42,83]Turn in[QT5537]
Accept[QA5538]
Turn in[QT5223]
IF CENARION HOLD IS ACTIVE, [H]Hearth to Menethil Harbor
IF IT IS NOT ACTIVE, Fly to Menethil Harbor
Take the southern boat to Theramore
[T]Train first aid if you need to
Fly to Gadgetzan
[G51.6,28.8Tanaris]Turn in[QT5538] ONLY if you have the 2 Thorium Bars
[QA5801]Accept the follow up for the key only if you have the bars[OC]
[G50.8,27]Turn in[QT4507]
Accept[QA4508]
[G51,27]Scare Sprinkle with the Mechanical yeti for [QC5163,2]
Loot all the items from the Aquamentas bag you got earlier[OC]
[G70,49]Opposite side of Caverns of Time, use the items in the stone circle, DONT LEAVE THE CIRCLE. Kill him and complete [QC4005]
Ride west across the desert into Un'Goro[OC]
[G48,48Un'Goro Crater]Stand next to the laval and forge the key for[QC5801]
[G44,9]Scare Quixxil with the Yeti for [QC5163]
Head into the cave at Marshall's Refuge and turn in[QT4005] at the back
Accept[QA3961]
[G44.6,8.2]Turn in[QT3961] -- you may have to have the totem equipped to turn it in.
Accept[QA3962] -- You'll need someone to help you solo this later, but it wont be covered in the guide.
THERE ARE NOW TWO OPTIONS FOR THE NEXT GUIDE!!!
If Cenarion hold is active Select the Guide '57-58 Silithus'
If the Cenarion Hold/Silithus quests WERE NOT available, then [H]Hearth to Menethil Harbor and select the guide '57-60 Western Plaguelands'
]],"Hakurai - by Shikushiku")