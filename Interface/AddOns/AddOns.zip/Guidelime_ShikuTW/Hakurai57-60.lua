Guidelime.registerGuide(
[[
[N 57-60 Western Plaguelands]
[GA Alliance]
[D Made from Hakurai's Video Guide\\ https://twitch.tv/hakurai \\ Our guild is recruiting! \\ https://www.guilded.gg/KOABD]
Start killing mobs in excess and as you travel, without Silithus in the game at launch, you will have to make up the xp some how!
You should be in Menethil Harbor. If you were able to do Silithus you're 58, if not, you're 57, but we're all going to the same place[OC]
Take the boat to Auberdine
Fly to Rut'theran Village
Teleport into Darnassus
Go to the Temple of the Moon and turn in[QT4508] on the second floor.
Accept[QA4510]
Head north and turn in[QT4510] at the bank in the center of Darnassus
[G35.2,8Darnassus]On the middle floor of the tree, turn in[QT4986]
[T]Train if you're level 58
Head back to the flightmaster
IF YOU DID SILITHUS -- FLY TO MOONGLADE
IF YOU DID NOT -- Fly to Winterspring
SILITHUS -- [G47.8,39.4Moonglade]Turn in[QT6844]
SILITHUS -- Accept[QA6845]
SILITHUS -- [G51.6,44.4]Turn in [QT6845]
SILITHUS -- turn in [QT5527] if it was available
SILITHUS -- [G47.8,39.4]Accept[QA1185]
SILITHUS -- Turn in[QT1185]
SILITHUS -- Fly to Winterspring
REJOIN THE GUIDE NOW
[G60.8,37.6Winterspring]Turn in[QT5163]
[G61.6,38.6]Turn in[QT4808]
Accept[QA4809]
Inside the inn accept[QA6030]if you don't have it. MAKE SURE YOU DIDNT TAKE JESSICA'S QUEST!!!
[G58,18]Kill Chillwind Chimeras until you finish [QC4809]
Keep grinding on them until your hearthstone is off cooldown[OC]
[G61.6,38.6]Turn in[QT4809]
Accept[QA4810]
[V]Sell trash
[H]Hearth to Menethil Harbor
Fly to Ironforge
[T]Train level 58 abilities if you can
[G38.6,55.2Ironforge]Turn in[QT3701]
Fly to Stormwind City
Take the relics out of your bank, all 4 of them[OC]
[G48.6,30.6Stormwind City]Second floor, turn in[QT5022]
Accept[QA5048]
[G52,43]Second floor, Turn in[QT5048]
[G78,17]Turn in[QT4184]If you have it[OC]
Accept[QA4185]
Speak to Lady Prestor toc omplete it, then turn in [QT4185]
Accept[QA4186]
[G78,17]Accept[QA6182]
[G75.8,59.8]Turn in[QT6182]
Accept[QA6183]
Turn in[QT6183]
Accept[QA6184]
IF YOU HAVE BEEN DOING TRUE MASTERS, CONTINUE, IF NOT, SKIP PAST THE 'TM' TAGS AND FLY TO CHILLWIND POINT!
TM - Fly to Redridge Mountains
TM - [G30,44.2Redridge Mountains]Turn in[QT4186]
TM - Accept[QA4223]
TM - Fly to Morgan's Vigil in Burning Steppes
TM - [G84.8,69Burning Steppes]Turn in[QT4223]
TM - Accept[QA4224]
TM - [G65.2,23.6]Turn in[QT4810]
TM - Talk to Ragged John until you complete [QC4224]
TM - [G84.8,69Burning Steppes]Turn in[QT4224]
TM - Accept[QA4242]
TM - Fly to Chillwind POINT
REJOIN THE GUIDE NOW!
Start looking for a group for Araj the Summoner, we get a quest in Chillwind to kill him and it gives a ton of XP before 60. A lot of these max level quests are much easier in a group.
[G42.8,84.2Western Plaguelands]Accept[QA5225]
Turn in[QT5801]if you did it.
Accept[QA5803]
Talk to Flint to turn in[QT6184]
Accept[QA6185]
Accept[QA5903] from Nathaniel
[G42.8,84]Accept[QA211] This is the Araj quest you need help with
[G48,79]Second floor, accept[QA5142]
[G39,54]Upstairs, turn in[QT5050]
Accept[QA5051]
Find a roaming named mob called Jabbering Ghoul, typically on the west side of the fields. Loot him for [QC5051]
[G39,54]Upstairs, turn in[QT5051]
[G63,58]Kill the mobs around the Cauldron, then kill the Cauldron lord for [QC5225]
Turn in[QT5225] at the cauldron
Accept[QA5226]
Follow the main road East into Eastern Plaguelands.[OC]
[G7.5,43.7Eastern Plaguelands]Accept [QA5542]
Accept[QA5543]
Accept[QA5544]
Work on all three of these quests while heading to the next spot. The runts and bats only spawn on the western side of EPL.
[G29,80]Loot the skeleton for The Eastern Plagues
[G29,75]Loot the skeleton for The Eastern Plagues
[G27,75]Loot the skeleton for The Eastern Plagues, don't aggro Nathanos
Mount up, Inch close enough to Nathanos to complete [QC6185] and the run away
[G36,90]Turn in[QT5142]
Accept[QA5149]
[G40,90]Loot the head inside next to the chimney[OC]
[G39,92]Loot the other two parts in the ruined houses, then combine the doll.[QC5142]
[G36,90]Turn in[QT5142]
Accept[QA5241]
Accept[QA5152]
[G50,45]Frenzied Plaguehounds can be found here - Finish [QC5542][QC5543][QC5544]
[G81,60]There's a lot of quests at Light's Hope, but most of them are dungeon quests, just accept what the guide tells you for now.
[G81,60]Turn in[QT6030]
[G81,59]Turn in[QT5241]
Accept[QA5211]
Grab the flightpath next to him[OC]
[V]Sell your trash
[G79.4,63.6]Accept[QA5281]
Accept[QA6021]
Fly to Chillwind Point
[G42.8,84.2Western Plaguelands]Turn in[QT5226]
Accept[QA5238]
Turn in[QT42.8,84]
Turn in the Araj quests if you did them[OC]
Turn in[QT6185] at Flint infront of the broken house.
Accept[QA6186]
You can choose to fly back to Stormwind and turn in The Blightcaller Cometh, but it's a long flight, if you don't turn it in you'll have to grind more later to make up the xp. This guide will take you to turn it in.[OC]
Fly to Stormwind
[G78.7,17.8Stormwind City]Turn in[QT6186]
Accept[QA6187]
[H]Hearth back to Menethil Harbor
Fly back to Chillwind
[G49,78Western Plaguelands]Upstairs, turn in[QT5152]
Accept[QA5153]
[G49,76]Outside, clear the mobs around the white Tombstone and loot it for [QC5153]
[G39,66]In Andorhall, upstairs in this building, turn in[QT5153]
Accept[QA5154]
Accept[QA4971]
Pause for a moment and pay your respects to the bae that gave us classic wow.[OC]
[G49,69]Use the quest items on the glowing blue silos until you kill 10 parasites for[QC4971]
[G39,66]Go back to Chromie and turn in[QT4971]
Accept[QA4972]
This quest wants you to loot lockboxes in the ruined houses. Basically 1 lockbox per house. Work on this while doing the next steps[OC]
[G43,68]Careful for the elites, if you hug the building you shouldn't pull them, if you do suicide inside the town hall so you can rez safely[OC]
Inside the town hall are a bunch of books. If you loot the wrong book, an elite will spawn and kill you. 
https://www.wowhead.com/item=12900/annals-of-darrowshire#screenshots:id=4980
Sneak back outside and finish clearing houses for [QC4972]
[G39,66]Back to Chromie, turn in[QT4972]
Turn in[QT5154]
Accept[QA5210]
Run north to the main road, out of Anderhall, follow the road to Eastern Plaguelands.
[G7.5,43.7Eastern Plaguelands]
Turn in[QT5542]
Turn in[QT5543]
Turn in[QT5544]
Accept[QA5742]
Tirion will only talk to you if you're sitting. /sit next to him and then talk to him.[QC5742]
Turn in[QT5742]
Accept[QA5781]
This is the last hard quest of the guide, and hard to solo[OC]
[G28,86]Stand on the dirt pile, right click the dirt which summons 4 mobs. Stay on the dirt pile until you loot the hammer. Kill the named mob and loot him for the hammer.[QC5781]
[G27,86]In the undercroft, enter the crypt and kill Zaeldarr for [QC6021]
Click the large scroll on the ground for [QA6024]
[G7.5,43.7Eastern Plaguelands]Turn in[QT5781]
Accept[QA5845]
Ride east to Light's Hope[OC]
[G81.4,59.6]Turn in[QT5210]
Accept[QA5168]
Accept[QA5181]
[G79.4,63.6]Turn in[QT6021]
[V]Sell trash
[G53,65]Loot the sword for [QC5181,2]
[G51,50]Loot the skull for [QC5181,1] on the bottom of the lake.
[G53,21]Turn in[QT5245]
Head west into the Plaguewood. Kill Cannibal Ghouls whenever you see them and talk to the spirit that spawns after you kill them.[OC]
Also keep an eye out for Plague termites, you loot them from the termite mounds.[OC]
[G14,33]Turn in[QT5281]
Accept[QA6164]From next to him.
[G17,31]The Inn building, upstairs on the second floor in the big room, grab the book for [QC6164]
[G14,33]Turn in[QT6164] - this unlocks a vendor. [V]Sell your trash at him
Finish [QC5211] and [QC5903]
[G71,16]Kill Inspector Hameya for his key[OC]
[G71,34]Loot the Symbol for [QC5845] under water
[G81.4,59.6]Turn in[QT5181]
Turn in[QT5211]
Fly to Chillwind Point
Turn in [QT5903] at Nathaniel
Accept[QA5904]
[G48,32]Click on the crate inside the mill. [QT5904]
Accept[QA6389]
Right click the barrel on top of the crate to complete[QC6389]
Run around the mountains and then across the river back to Tirion[OC]
[G7.5,43.7Eastern Plaguelands]Turn in[QT5845]
Accept[QA5846]
[G28,86]Talk to the dirt and turn in [QT6024]
[G65,75Western Plaguelands]Turn in[QT5846]
Accept[QA5848]This is a strat quest, but has a lot of great pre-raid gear as a reward.
Go back to Chillwind Point[OC]
Turn in[QT6389] at Nathaniel
You should be  60 or fairly close. We've finished most of the soloable quests, so now you have the option to grind it out, run BRD, or try to get groups for Heros of Darrowshire or Araj if you haven't yet.[OC]
Thank you to Hakurai for making this guide
https://twitch.tv/Hakurai
Please consider stopping by my wife's stream
https://twitch.tv/angelsoultv
And lastly our guild is always recruiting, we play Fairbanks on NA
https://www.guilded.gg/KOABD
I hope my guide has helpepd you in some way. Please enjoy the rest of your time in Azeroth \\ Thank you, \\ Shiku/Alexei
]],"Hakurai - by Shikushiku")